package de.unidue.inf.is.domain;

public class Registration {
}
