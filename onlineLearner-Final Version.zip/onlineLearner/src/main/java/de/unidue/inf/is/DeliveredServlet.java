package de.unidue.inf.is;

import javax.servlet.http.HttpServlet;

public class DeliveredServlet extends HttpServlet {
}
